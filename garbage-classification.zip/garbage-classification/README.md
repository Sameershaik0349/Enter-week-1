# ♻️ Garbage Classification using AI

This project uses deep learning to classify waste into categories like Organic, Recyclable, Hazardous, etc.

## Features
- Image classification using CNN
- Model training and prediction
- Flask app for image upload and prediction

## Installation
```
pip install -r requirements.txt
```

## Usage
To train the model:
```
python src/train.py
```

To start the app:
```
python app.py
```
