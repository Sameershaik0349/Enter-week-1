import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
import io

model = tf.keras.models.load_model('model/model.h5')
class_names = ['organic', 'recyclable', 'hazardous']

def predict_image(file):
    img = image.load_img(file, target_size=(128, 128))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0

    predictions = model.predict(img_array)
    class_index = np.argmax(predictions[0])
    return class_names[class_index]
