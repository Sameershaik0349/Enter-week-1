from flask import Flask, request, render_template
import os
from src.predict import predict_image

app = Flask(__name__)

@app.route('/')
def index():
    return "Garbage Classification API is running."

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return "No file uploaded", 400
    file = request.files['file']
    prediction = predict_image(file)
    return {"prediction": prediction}

if __name__ == "__main__":
    app.run(debug=True)
